#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>


using namespace std;


vector<string> split(const string &s, char delimiter) {
    vector<string> result;

    string item;
    istringstream iss(s);

    while (std::getline(iss, item, delimiter))
        result.push_back(item);

    return result;
}

float stof_noexcept(
    const string &s,
    float default_value = numeric_limits<float>::infinity()
) noexcept {
    try {
        return stof(s);
    }
    catch (...) {
        return default_value;
    }
}

int main(int argc, char *argv[]) {
    const bool name_presented = true;
    const int coords_count    = 2;
    const int samples_count   = 5000;
    const int points_count    = 4;
    const int total_entities =
        (int)name_presented + coords_count + samples_count + points_count + 1;

    const int cluster_offset = (int)name_presented + coords_count + samples_count;
    const int points_offset =
        (int)name_presented + coords_count + samples_count + 1;


    if (argc < 2) {
        cerr << "Filename must be presented as command line argument.";
        return -1;
    }

    string filename(argv[1]);
    ifstream csv_file(filename);

    if (!csv_file.is_open()) {
        cerr << "Can't open file " << filename << ".";
        return -1;
    }


    int K_score       = 0;
    int C_score       = 0;
    int signals_count = 0;
    int success_count = 0;


    while (true) {
        bool success = true;
        string line;

        int c;
        while ((c = csv_file.get()) && c != '\n' && c != char_traits<char>::eof())
            line.append(1, static_cast<char>(c));

        replace(line.begin(), line.end(), ' ', ',');

        auto parsed = split(line, ',');
        auto rm     = remove_if(parsed.begin(), parsed.end(), [](const auto &v) {
            return v.empty();
        });
        parsed.erase(rm, parsed.end());

        if (c == char_traits<char>::eof() && parsed.empty())
            break;

        if (parsed.size() != total_entities) {
            cout << "ERROR: Signal with index=" << signals_count
                 << ": has invalid format" << endl;
            success = false;
        }

        string name = parsed[0];

        float x = stof_noexcept(parsed[1]);
        float y = stof_noexcept(parsed[2]);

        if (isnan(x) || isinf(y) || isnan(x) || isinf(y)) {
            cout << "ERROR: Signal " << name << ": has invalid coordinates"
                 << "(" << x << ", " << y << ")" << endl;
            continue;
        }

        int cluster = stoi(parsed[cluster_offset]);
        if (cluster < 0 || cluster > 6) {
            cout << "ERROR: Signal " << name << ": has invalid cluster value"
                 << "(" << cluster << ")" << endl;
            success = false;
        }
        else
            ++K_score;

        std::vector<float> points;
        for (int i = 0; i < points_count; ++i)
            points.push_back(stof_noexcept(parsed[points_offset + i]));


        if (points.size() != points_count) {
            cout << "ERROR: Signal " << name << ": incorrect points count ("
                 << points.size() << ", needed " << points_count << ")" << endl;
            success = false;
        }

        for (int i = 0; i < points_count; ++i) {
            if (points[i] == -1.f || isnan(points[i]) || isinf(points[i])) {
                cout << "ERROR: Signal " << name << ": point " << i
                     << ": has undefined value (-1)" << endl;
                success = false;
            }
            else
                ++C_score;
        }

        ++signals_count;
        if (success)
            ++success_count;

        if (c == char_traits<char>::eof())
            break;
    }

    C_score /= 4;
    float percent = 100 * (K_score + C_score) / 2.f / (float)signals_count;

    if (success_count == signals_count)
        cout << "Validation passed completely!" << endl;
    cout << endl
         << "Valid signals " << success_count << " from " << signals_count << " ("
         << percent << " %)" << endl;
}
