#pragma once

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>


struct signal {
    int index;
    float x;
    float y;

    std::vector<float> data;
    std::vector<float> points;

    int cluster;
};

std::vector<std::string> split(const std::string &s, char delim);

std::vector<signal> read_signals(const std::string &filename) {
    const bool name_presented = true;
    const int coords_count    = 2;
    const int samples_count   = 5000;
    const int points_count    = 4;
    const int total_entities =
        (int)name_presented + coords_count + samples_count + points_count + 1;

    const int data_offset    = (int)name_presented + coords_count;
    const int cluster_offset = (int)name_presented + coords_count + samples_count;
    const int points_offset =
        (int)name_presented + coords_count + samples_count + 1;

    std::vector<signal> result;

    std::ifstream csv_file(filename);

    if (!csv_file.is_open())
        throw std::runtime_error("can't open file");

    while (true) {
        signal sig;
        std::string line;

        int c;
        while ((c = csv_file.get()) && c != '\n'
               && c != std::char_traits<char>::eof())
            line.append(1, static_cast<char>(c));

        replace(line.begin(), line.end(), ' ', ',');

        auto parsed = split(line, ',');
        auto rm = std::remove_if(parsed.begin(), parsed.end(), [](const auto &v) {
            return v.empty();
        });
        parsed.erase(rm, parsed.end());

        if (c == std::char_traits<char>::eof() && parsed.empty())
            break;

        if (parsed.size() != total_entities)
            throw std::runtime_error("invalid signal format");

        sig.index   = std::stoi(parsed[0]);
        sig.x       = std::stof(parsed[1]);
        sig.y       = std::stof(parsed[2]);
        sig.cluster = std::stoi(parsed[cluster_offset]);

        for (int i = 0; i < samples_count; ++i)
            sig.data.push_back(std::stof(parsed[data_offset + i]));

        for (int i = 0; i < points_count; ++i)
            sig.points.push_back(std::stof(parsed[points_offset + i]));

        result.push_back(sig);

        if (c == std::char_traits<char>::eof())
            break;
    }

    return result;
}


std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> result;

    std::string item;
    std::istringstream iss(s);

    while (std::getline(iss, item, delim))
        result.push_back(item);

    return result;
}
